
class Food:
    def __init__(self,name,price,quantity):
         
        self.name=name
        self.quantity=quantity
        self.price=price
    
    


class Pizza(Food):
    pass
class Drinks(Food):
    pass
class Burger(Food):
    pass
class Coffie(Food):
    pass

